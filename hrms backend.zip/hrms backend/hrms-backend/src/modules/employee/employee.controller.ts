import { Request, Response, NextFunction } from "express";
import { EmployeeService } from "./employee.service";
import { buildSuccessResponse } from "../../core/database/base.schema";
import { ListEmployeesQueryDto } from "./employee.dto";

const empService = new EmployeeService();

export class EmployeeController {
  // POST /api/v1/employees
  async create(
    req:  Request,
    res:  Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const result = await empService.createEmployee(req.context, req.body);
      res.status(201).json(
        buildSuccessResponse(result, "Employee created successfully")
      );
    } catch (error) { 
        next(error); 
    }
  }

  // GET /api/v1/employees
  async list(
    req:  Request,
    res:  Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const query = ListEmployeesQueryDto.parse(req.query);
      const result = await empService.listEmployees(req.context, query);
      res.status(200).json(result);
    } catch (error) { 
        next(error); 
    }
  }

  // GET /api/v1/employees/:id
  async getById(
    req:  Request<{ id: string }>,
    res:  Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const result = await empService.getEmployeeById(req.context, req.params.id);
      res.status(200).json(
        buildSuccessResponse(result, "Employee fetched successfully")
      );
    } catch (error) { 
        next(error); 
    }
  }

  // GET /api/v1/employees/me
  async getMyProfile(
    req : Request,
    res : Response,
    next : NextFunction
  ):Promise<void>{
    try{
      const result = await empService.getMyProfile(req.context);
      res.status(200).json(
        buildSuccessResponse(result, "Your profile fetched successfully")
      );
    }catch (error) {
      next(error)
    }
  }

  // PATCH /api/v1/employees/:id
  async update(
    req:  Request<{ id: string }>,
    res:  Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const result = await empService.updateEmployee(
        req.context, req.params.id, req.body
      );
      res.status(200).json(
        buildSuccessResponse(result, "Employee updated successfully")
      );
    } catch (error) { 
        next(error); 
    }
  }

  // PATCH /api/v1/employees/:id/status
  async updateStatus(
    req:  Request<{ id: string }>,
    res:  Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const result = await empService.updateEmployeeStatus(
        req.context, req.params.id, req.body
      );
      res.status(200).json(
        buildSuccessResponse(result, "Employee status updated")
      );
    } catch (error) { 
        next(error); 
    }
  }

  // DELETE /api/v1/employees/:id
  async delete(
    req:  Request<{ id: string }>,
    res:  Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const result = await empService.deleteEmployee(
        req.context, req.params.id
      );
      res.status(200).json(
        buildSuccessResponse(result, "Employee deleted successfully")
      );
    } catch (error) { 
        next(error); 
    }
  }

  // POST /api/v1/employees/:id/bank-accounts
  async addBankAccount(
    req:  Request<{ id: string }>,
    res:  Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const result = await empService.addBankAccount(
        req.context, req.params.id, req.body
      );
      res.status(201).json(
        buildSuccessResponse(result, "Bank account added successfully")
      );
    } catch (error) { 
        next(error); 
    }
  }

  // GET /api/v1/employees/:id/bank-accounts
  async getBankAccounts(
    req:  Request<{ id: string }>,
    res:  Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const result = await empService.getBankAccounts(
        req.context, req.params.id
      );
      res.status(200).json(
        buildSuccessResponse(result, "Bank accounts fetched successfully")
      );
    } catch (error) { 
        next(error); 
    }
  }

  // DELETE /api/v1/employees/:id/bank-accounts/:bankId
  async deleteBankAccount(
    req:  Request<{ id: string; bankId: string }>,
    res:  Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const result = await empService.deleteBankAccount(
        req.context, req.params.id, req.params.bankId
      );
      res.status(200).json(
        buildSuccessResponse(result, "Bank account removed")
      );
    } catch (error) { 
        next(error); 
    }
  }

  // POST /api/v1/employees/:id/documents
  async addDocument(
    req:  Request<{ id: string }>,
    res:  Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const result = await empService.addDocument(
        req.context, req.params.id, req.body
      );
      res.status(201).json(
        buildSuccessResponse(result, "Document added successfully")
      );
    } catch (error) { 
        next(error); 
    }
  }

  // GET /api/v1/employees/:id/documents
  async getDocuments(
    req:  Request<{ id: string }>,
    res:  Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const result = await empService.getDocuments(
        req.context, req.params.id
      );
      res.status(200).json(
        buildSuccessResponse(result, "Documents fetched successfully")
      );
    } catch (error) { 
        next(error); 
    }
  }

  // DELETE /api/v1/employees/:id/documents/:docId
  async deleteDocument(
    req:  Request<{ id: string; docId: string }>,
    res:  Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const result = await empService.deleteDocument(
        req.context, req.params.id, req.params.docId
      );
      res.status(200).json(
        buildSuccessResponse(result, "Document removed")
      );
    } catch (error) { 
        next(error); 
    }
  }
}